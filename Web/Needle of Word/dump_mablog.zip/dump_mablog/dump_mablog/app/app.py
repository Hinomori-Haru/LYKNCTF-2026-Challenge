#!/usr/bin/env python3
"""BlogSpace — A collaborative blog platform."""

import os
import re
import time
import json
import hmac
import base64
import random
import hashlib
import sqlite3
from pathlib import Path
from functools import wraps

import jwt  # PyJWT
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
from flask import (
    Flask, render_template, render_template_string, request,
    session, redirect, url_for, jsonify, send_from_directory,
    abort, g, flash,
)

# ─── App Setup ────────────────────────────────────────────────────────────────
app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("SECRET_KEY", "blogspace-k8xQm2p9nL5vR7")
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

BASE_DIR   = Path(__file__).parent.resolve()
KEYS_DIR   = BASE_DIR / "keys"
STATIC_DIR = BASE_DIR / "static"
DB_PATH    = BASE_DIR / "blog.db"

FLAG = os.environ.get("FLAG", "CTF{test_flag_replace_in_production}")

# ─── RSA Key Management ───────────────────────────────────────────────────────
def _init_keys():
    KEYS_DIR.mkdir(exist_ok=True)
    STATIC_DIR.mkdir(exist_ok=True)
    priv_path = KEYS_DIR / "private.pem"
    pub_path  = KEYS_DIR / "public.pem"
    if not priv_path.exists():
        private_key = rsa.generate_private_key(
            public_exponent=65537, key_size=2048, backend=default_backend()
        )
        priv_pem = private_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
        pub_pem = private_key.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        priv_path.write_bytes(priv_pem)
        pub_path.write_bytes(pub_pem)
    (STATIC_DIR / "jwt_pub.pem").write_bytes(pub_path.read_bytes())


_init_keys()

def _priv_key():  return (KEYS_DIR / "private.pem").read_bytes()
def _pub_key():   return (KEYS_DIR / "public.pem").read_bytes()

# ─── JWT Utilities ────────────────────────────────────────────────────────────
def create_jwt(user_id: int, username: str, role: str = "user") -> str:
    payload = {
        "sub": user_id,
        "username": username,
        "role": role,
        "iat": int(time.time()),
        "exp": int(time.time()) + 86400 * 7,
    }
    return jwt.encode(payload, _priv_key(), algorithm="RS256")


def decode_jwt(token: str):
    try:
        header = jwt.get_unverified_header(token)
        algorithm = header.get("alg", "RS256")
        if algorithm == "RS256":
            return jwt.decode(token, _pub_key(), algorithms=["RS256"])
        elif algorithm == "HS256":
            parts = token.split(".")
            if len(parts) != 3:
                return None
            signing_input = f"{parts[0]}.{parts[1]}".encode()
            try:
                expected_sig = base64.urlsafe_b64decode(parts[2] + "==")
            except Exception:
                return None
            actual_sig = hmac.new(_pub_key(), signing_input, hashlib.sha256).digest()
            if not hmac.compare_digest(expected_sig, actual_sig):
                return None
            payload = json.loads(base64.urlsafe_b64decode(parts[1] + "=="))
            if payload.get("exp", 0) < int(time.time()):
                return None
            return payload
    except Exception:
        pass
    return None


def get_jwt_payload():
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return decode_jwt(auth[7:])
    token = request.cookies.get("access_token", "")
    if token:
        return decode_jwt(token)
    return None

# ─── Database ─────────────────────────────────────────────────────────────────
def get_db():
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(_=None):
    conn = g.pop("db", None)
    if conn:
        conn.close()


def hash_pw(passwd: str) -> str:
    return hashlib.sha256(passwd.encode()).hexdigest()


def _init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            username     TEXT UNIQUE NOT NULL,
            email        TEXT UNIQUE NOT NULL,
            password     TEXT NOT NULL,
            bio          TEXT DEFAULT '',
            avatar_color TEXT DEFAULT '#4285F4',
            is_moderator INTEGER DEFAULT 0,
            is_admin     INTEGER DEFAULT 0,
            created_at   TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS posts (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            title        TEXT NOT NULL,
            content      TEXT NOT NULL,
            excerpt      TEXT DEFAULT '',
            author_id    INTEGER NOT NULL,
            status       TEXT DEFAULT 'draft',
            tags         TEXT DEFAULT '',
            read_time    INTEGER DEFAULT 3,
            created_at   TEXT DEFAULT CURRENT_TIMESTAMP,
            published_at TEXT,
            FOREIGN KEY (author_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS admin_notes (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            title      TEXT NOT NULL,
            content    TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
    """)
    if not conn.execute("SELECT id FROM users WHERE username='admin'").fetchone():
        conn.execute(
            "INSERT INTO users (username,email,password,bio,avatar_color,is_moderator,is_admin) VALUES (?,?,?,?,?,1,1)",
            ("admin","admin@blogspace.io", hash_pw("blogmaster"),
             "Platform administrator. Keeping the lights on.", "#EA4335"),
        )
        conn.execute(
            "INSERT INTO users (username,email,password,bio,avatar_color,is_moderator) VALUES (?,?,?,?,?,1)",
            ("sarah_m","sarah@blogspace.io", hash_pw("springtime22"),
             "Content moderator & frontend developer. Coffee enthusiast.", "#34A853"),
        )
        conn.execute(
            "INSERT INTO users (username,email,password,bio,avatar_color) VALUES (?,?,?,?,?)",
            ("alex_dev","alex@example.com", hash_pw("alexpass99"),
             "Full-stack dev writing about JS, Python & system design.", "#FBBC05"),
        )
        conn.execute(
            "INSERT INTO users (username,email,password,bio,avatar_color) VALUES (?,?,?,?,?)",
            ("maria_writes","maria@example.com", hash_pw("maria2024"),
             "UX designer turned writer. I love accessible, beautiful software.", "#9C27B0"),
        )

        posts = [
            ("Understanding Async/Await in JavaScript",
             "<p>Asynchronous programming has always been a complex topic in JavaScript. Before async/await, developers relied on callback functions—leading to the infamous <em>callback hell</em>.</p><p>With async/await (ES2017), writing async code became dramatically more readable:</p><pre><code>async function fetchUser(id) {\n  const res = await fetch(`/api/users/${id}`);\n  return res.json();\n}</code></pre><h2>Error Handling</h2><p>One of the biggest wins is cleaner error handling via standard <code>try/catch</code> instead of chaining <code>.catch()</code>:</p><pre><code>try {\n  const user = await fetchUser(123);\n  console.log(user.name);\n} catch (err) {\n  console.error('Failed:', err);\n}</code></pre><p>Under the hood, async/await is syntactic sugar over Promises. Understanding the event loop makes debugging async code significantly easier.</p>",
             "How async/await transforms asynchronous JavaScript from callback hell to readable, maintainable code.",
             3, "published", "javascript,async,programming", 6),

            ("Why I Switched from REST to GraphQL",
             "<p>After three years building REST APIs, I switched to GraphQL on our main product—and haven't looked back.</p><h2>The Problem with REST</h2><p>REST APIs suffer from over-fetching and under-fetching. Our mobile app was making 7 separate API calls just to render the home screen. Each added latency, creating a waterfall that killed our performance metrics.</p><h2>GraphQL to the Rescue</h2><pre><code>query {\n  user(id: \"123\") {\n    name\n    posts(limit: 5) {\n      title\n      publishedAt\n      comments { count }\n    }\n  }\n}</code></pre><p>One request. Performance improved 40%. The client specifies exactly what it needs—no more, no less.</p><h2>The Tradeoffs</h2><p>GraphQL isn't a silver bullet. Caching is more complex, rate limiting is trickier, and the learning curve is steep. Monitoring also requires different tooling. For data-heavy applications with complex relationships, the tradeoffs are worth it.</p>",
             "After three years of REST, here's my honest assessment of the switch to GraphQL.",
             3, "published", "graphql,api,backend", 7),

            ("Design Systems: The Good, The Bad, and The Painful",
             "<p>Building a design system from scratch is one of the most rewarding—and exhausting—things I've done. I've done it twice. Here's what I wish I'd known.</p><h2>Start with Tokens</h2><p>Tokens before components. Tokens encode your design decisions: colors, typography scales, spacing, shadows, border radii. Get the token structure wrong and you'll be refactoring forever.</p><h2>The Component Trap</h2><p>Most teams build too many components too quickly. Every component you add is one you must maintain, document, and keep in sync. Start with the basics—typography, color, spacing, button, input, card—and add more only when the same pattern appears three or more times in production.</p><h2>Documentation is Product</h2><p>A design system without documentation is just a component library. The docs communicate intent, show examples, and explain when to use what. Without them, the system is invisible to the people who need it most.</p>",
             "Two design systems in—everything I wish I knew before starting.",
             4, "published", "design,ux,systems", 8),

            ("Python Type Hints: A Practical Guide",
             "<p>Python's dynamic typing is a strength—until it becomes a source of bugs at scale. Type hints, introduced in Python 3.5, offer a middle ground: optional static typing that improves IDE support and catches errors before runtime.</p><h2>The Basics</h2><pre><code>def greet(name: str) -> str:\n    return f\"Hello, {name}!\"\n\ndef add(a: int, b: int) -> int:\n    return a + b</code></pre><h2>Collections</h2><pre><code>from typing import Optional\n\ndef find_user(user_id: int) -> Optional[dict]:\n    ...</code></pre><p>In Python 3.9+, you can use built-in generics directly: <code>list[str]</code>, <code>dict[str, int]</code>.</p><h2>When to Use Them</h2><p>Type hints shine in larger codebases, public APIs, and anywhere multiple developers collaborate. My rule: add type hints to any function that will be called by code you don't control.</p>",
             "Everything you need to know about Python type hints, from basic annotations to complex generics.",
             3, "published", "python,typing,programming", 6),

            ("Building a SaaS in 90 Days: The Honest Story",
             "<p>Ninety days ago I had an idea. Today I have paying customers. Here's everything that happened in between.</p><h2>Days 1–15: Validate Before You Build</h2><p>I spent the first two weeks talking to potential customers—28 interviews in 14 days. I nearly gave up twice. By day 15, six people said they'd pay for a solution. That was enough.</p><h2>Days 16–45: The Build Sprint</h2><p>I chose the most boring technology stack I knew: Next.js, PostgreSQL, Stripe. No new frameworks. Boring technology means fewer surprises. I shipped an MVP on day 44. It was rough. My early access customers loved it anyway.</p><h2>Days 46–90: First Revenue</h2><p>First payment on day 51. $49/month. I stared at the screenshot for ten minutes. By day 75: 11 customers, $539 MRR. Not life-changing, but proof the model works.</p><ul><li>Validate before you build. Every time.</li><li>Boring technology is a feature.</li><li>The first 10 customers are the hardest.</li></ul>",
             "The unfiltered story of taking a SaaS from idea to first revenue in 90 days.",
             3, "published", "startup,saas,entrepreneurship", 10),

            ("CSS Grid vs Flexbox: When to Use Which",
             "<p>The eternal CSS question. Both solve layout problems, but different ones.</p><h2>The One-Sentence Rule</h2><p><strong>Flexbox</strong> for one-dimensional layouts (row <em>or</em> column). <strong>Grid</strong> for two-dimensional layouts (rows <em>and</em> columns). That covers 90% of cases.</p><h2>Flexbox Wins For...</h2><pre><code>.nav {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 1rem;\n}</code></pre><p>Navigation bars, button groups, centering—anywhere you're aligning items along one axis.</p><h2>Grid Wins For...</h2><pre><code>.card-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));\n  gap: 1.5rem;\n}</code></pre><p>Page layouts, card grids, complex component arrangements where items must align on both axes.</p><h2>Use Both Together</h2><p>The best layouts use Grid for macro structure and Flexbox for micro arrangements within components. They're complementary, not competing.</p>",
             "A practical breakdown of when to reach for CSS Grid versus Flexbox.",
             4, "published", "css,webdev,design", 5),
        ]
        for title, content, excerpt, author_id, status, tags, read_time in posts:
            conn.execute(
                "INSERT INTO posts (title,content,excerpt,author_id,status,tags,read_time,published_at) VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                (title, content, excerpt, author_id, status, tags, read_time),
            )
        conn.execute(
            "INSERT INTO posts (title,content,excerpt,author_id,status,tags,read_time) VALUES (?,?,?,?,?,?,?)",
            ("My Thoughts on AI in 2025", "<p>AI is everywhere now...</p>",
             "An honest take on where AI is heading.", 3, "pending", "ai,opinion", 4),
        )

        conn.execute(
            "INSERT INTO admin_notes (title,content) VALUES (?,?)",
            ("Platform Roadmap Q3",
             "Key items for Q3:\n1. Improve moderation workflow\n2. Add comment system\n3. Newsletter integration\n\nBudget approved. Start planning.\n\nP.S. Remember to rotate API keys before launch."),
        )
        conn.execute(
            "INSERT INTO admin_notes (title,content) VALUES (?,?)",
            ("Moderator Guidelines",
             "When reviewing posts:\n- Check for spam and duplicate content\n- Verify technical accuracy for dev posts\n- Approve within 48 hours\n- Use the dashboard search to find related content before approving anything."),
        )
        conn.commit()
    conn.close()


with app.app_context():
    _init_db()

# ─── Auth Helpers ─────────────────────────────────────────────────────────────
@app.before_request
def load_user():
    g.user = None
    if "user_id" in session:
        row = get_db().execute(
            "SELECT * FROM users WHERE id=?", (session["user_id"],)
        ).fetchone()
        if row:
            g.user = dict(row)


def login_required(f):
    @wraps(f)
    def inner(*a, **kw):
        if not g.user:
            return redirect(url_for("login", next=request.url))
        return f(*a, **kw)
    return inner


def moderator_required(f):
    @wraps(f)
    def inner(*a, **kw):
        if not g.user or not g.user.get("is_moderator"):
            abort(403)
        return f(*a, **kw)
    return inner


def admin_required(f):
    @wraps(f)
    def inner(*a, **kw):
        if not g.user or not g.user.get("is_admin"):
            abort(403)
        return f(*a, **kw)
    return inner

# ─── Static Assets ────────────────────────────────────────────────────────────
@app.route("/static/")
def static_listing():
    entries = []
    for item in sorted(STATIC_DIR.iterdir()):
        file_stat = item.stat()
        entries.append({
            "name": item.name,
            "size": file_stat.st_size,
            "mtime": time.strftime("%d-%b-%Y %H:%M", time.localtime(file_stat.st_mtime)),
            "is_dir": item.is_dir(),
        })
    return render_template("static_listing.html", entries=entries)


@app.route("/static/<path:filename>")
def serve_static(filename):
    return send_from_directory(STATIC_DIR, filename)

# ─── Public Routes ────────────────────────────────────────────────────────────
@app.route("/")
def index():
    conn = get_db()
    posts = conn.execute(
        "SELECT p.*,u.username,u.avatar_color FROM posts p "
        "JOIN users u ON p.author_id=u.id WHERE p.status='published' "
        "ORDER BY p.published_at DESC"
    ).fetchall()
    featured = posts[0] if posts else None
    rest = list(posts[1:])
    all_tags = []
    for p in posts:
        all_tags += [t.strip() for t in p["tags"].split(",") if t.strip()]
    tag_counts = {}
    for t in all_tags:
        tag_counts[t] = tag_counts.get(t, 0) + 1
    return render_template("index.html", featured=featured, posts=rest,
                           tags=tag_counts, tag_filter=None, user=g.user)


@app.route("/tag/<tag>")
def posts_by_tag(tag):
    conn = get_db()
    posts = conn.execute(
        "SELECT p.*,u.username,u.avatar_color FROM posts p "
        "JOIN users u ON p.author_id=u.id "
        "WHERE p.status='published' AND p.tags LIKE ? ORDER BY p.published_at DESC",
        (f"%{tag}%",)
    ).fetchall()
    return render_template("index.html", featured=None, posts=list(posts),
                           tags={}, tag_filter=tag, user=g.user)


@app.route("/post/<int:post_id>")
def view_post(post_id):
    conn = get_db()
    post = conn.execute(
        "SELECT p.*,u.username,u.avatar_color,u.bio as author_bio "
        "FROM posts p JOIN users u ON p.author_id=u.id "
        "WHERE p.id=? AND p.status='published'",
        (post_id,)
    ).fetchone()
    if not post:
        abort(404)
    tags = [t.strip() for t in post["tags"].split(",") if t.strip()]
    related = []
    if tags:
        related = conn.execute(
            "SELECT p.id,p.title,p.excerpt,u.username FROM posts p "
            "JOIN users u ON p.author_id=u.id "
            "WHERE p.status='published' AND p.id!=? AND p.tags LIKE ? LIMIT 3",
            (post_id, f"%{tags[0]}%")
        ).fetchall()
    return render_template("post.html", post=post, related=related, user=g.user)

# ─── Auth Routes ──────────────────────────────────────────────────────────────
@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("index"))
    error = None
    if request.method == "POST":
        uname  = request.form.get("username", "").strip()
        passwd = request.form.get("password", "")
        user   = get_db().execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (uname, hash_pw(passwd))
        ).fetchone()
        if user:
            session.clear()
            session["user_id"] = user["id"]
            role = "admin" if user["is_admin"] else ("moderator" if user["is_moderator"] else "user")
            token = create_jwt(user["id"], user["username"], role)
            resp = redirect(request.args.get("next") or url_for("index"))
            resp.set_cookie("access_token", token, httponly=True, samesite="Lax", max_age=86400 * 7)
            return resp
        error = "Invalid username or password."
    return render_template("login.html", error=error, user=g.user)


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("index"))
    error = None
    if request.method == "POST":
        uname   = request.form.get("username", "").strip()
        email   = request.form.get("email", "").strip()
        passwd  = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if len(uname) < 3:
            error = "Username must be at least 3 characters."
        elif len(passwd) < 6:
            error = "Password must be at least 6 characters."
        elif passwd != confirm:
            error = "Passwords do not match."
        else:
            colors = ["#4285F4", "#34A853", "#FBBC05", "#EA4335", "#9C27B0", "#00BCD4"]
            color = random.choice(colors)
            try:
                conn = get_db()
                conn.execute(
                    "INSERT INTO users (username,email,password,avatar_color) VALUES (?,?,?,?)",
                    (uname, email, hash_pw(passwd), color)
                )
                conn.commit()
                user = conn.execute("SELECT * FROM users WHERE username=?", (uname,)).fetchone()
                session.clear()
                session["user_id"] = user["id"]
                token = create_jwt(user["id"], user["username"], "user")
                resp = redirect(url_for("index"))
                resp.set_cookie("access_token", token, httponly=True, samesite="Lax", max_age=86400 * 7)
                return resp
            except sqlite3.IntegrityError:
                error = "Username or email is already taken."
    return render_template("register.html", error=error, user=g.user)


@app.route("/logout")
def logout():
    session.clear()
    resp = redirect(url_for("index"))
    resp.delete_cookie("access_token")
    return resp

# ─── User Routes ──────────────────────────────────────────────────────────────
@app.route("/write", methods=["GET", "POST"])
@login_required
def write_post():
    if request.method == "POST":
        title   = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        tags    = request.form.get("tags", "").strip()
        if not title or not content:
            return render_template("write.html", error="Title and content are required.", user=g.user)
        excerpt    = re.sub(r"<[^>]+>", "", content)[:220] + "…"
        word_count = len(re.sub(r"<[^>]+>", "", content).split())
        read_time  = max(1, word_count // 200)
        conn = get_db()
        conn.execute(
            "INSERT INTO posts (title,content,excerpt,author_id,status,tags,read_time) VALUES (?,?,?,?,'pending',?,?)",
            (title, content, excerpt, g.user["id"], tags, read_time)
        )
        conn.commit()
        flash("Your post has been submitted for review!", "success")
        return redirect(url_for("my_posts"))
    return render_template("write.html", user=g.user)


@app.route("/my-posts")
@login_required
def my_posts():
    posts = get_db().execute(
        "SELECT * FROM posts WHERE author_id=? ORDER BY created_at DESC",
        (g.user["id"],)
    ).fetchall()
    return render_template("my_posts.html", posts=posts, user=g.user)


@app.route("/profile")
@login_required
def profile():
    return render_template("profile.html", user=g.user)

# ─── API Routes ───────────────────────────────────────────────────────────────
@app.route("/api/token")
@login_required
def api_token():
    role = "admin" if g.user["is_admin"] else ("moderator" if g.user["is_moderator"] else "user")
    return jsonify({"token": create_jwt(g.user["id"], g.user["username"], role), "role": role})


@app.route("/api/profile/update", methods=["POST"])
def api_profile_update():
    payload = get_jwt_payload()
    if not payload or payload.get("role") not in ("moderator", "admin"):
        return jsonify({"error": "Forbidden — moderator JWT required"}), 403

    user_id = payload.get("sub")
    data = request.json
    if not data or not isinstance(data, dict):
        return jsonify({"error": "Invalid request body"}), 400

    conn = get_db()
    for field, value in data.items():
        try:
            conn.execute(f"UPDATE users SET {field}=? WHERE id=?", (value, user_id))
        except Exception:
            pass
    conn.commit()
    updated = conn.execute(
        "SELECT id,username,email,bio,is_moderator,is_admin FROM users WHERE id=?",
        (user_id,)
    ).fetchone()
    return jsonify({"success": True, "user": dict(updated)})

# ─── Moderator Dashboard ──────────────────────────────────────────────────────
@app.route("/dashboard")
@moderator_required
def dashboard():
    conn = get_db()
    pending = conn.execute(
        "SELECT p.*,u.username FROM posts p JOIN users u ON p.author_id=u.id "
        "WHERE p.status='pending' ORDER BY p.created_at DESC"
    ).fetchall()
    stats = {
        "published": conn.execute("SELECT COUNT(*) FROM posts WHERE status='published'").fetchone()[0],
        "pending":   len(pending),
        "users":     conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
    }
    return render_template("dashboard.html", pending=pending, stats=stats,
                           results=None, q="", user=g.user)


@app.route("/dashboard/search")
@moderator_required
def dashboard_search():
    q = request.args.get("q", "")
    conn = get_db()
    results = []
    try:
        cursor = conn.execute(
            f"SELECT p.id,p.title,p.status,p.created_at,u.username "
            f"FROM posts p JOIN users u ON p.author_id=u.id "
            f"WHERE p.title LIKE '%{q}%'"
        )
        results = cursor.fetchall()
    except Exception:
        pass
    pending = conn.execute(
        "SELECT p.*,u.username FROM posts p JOIN users u ON p.author_id=u.id "
        "WHERE p.status='pending' ORDER BY p.created_at DESC"
    ).fetchall()
    stats = {
        "published": conn.execute("SELECT COUNT(*) FROM posts WHERE status='published'").fetchone()[0],
        "pending":   len(pending),
        "users":     conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
    }
    return render_template("dashboard.html", pending=pending, stats=stats,
                           results=results, q=q, user=g.user)


@app.route("/dashboard/approve/<int:post_id>", methods=["POST"])
@moderator_required
def approve_post(post_id):
    conn = get_db()
    conn.execute("UPDATE posts SET status='published',published_at=CURRENT_TIMESTAMP WHERE id=?", (post_id,))
    conn.commit()
    return redirect(url_for("dashboard"))


@app.route("/dashboard/reject/<int:post_id>", methods=["POST"])
@moderator_required
def reject_post(post_id):
    conn = get_db()
    conn.execute("UPDATE posts SET status='rejected' WHERE id=?", (post_id,))
    conn.commit()
    return redirect(url_for("dashboard"))

# ─── Admin Routes ─────────────────────────────────────────────────────────────
@app.route("/admin/notes")
@admin_required
def admin_notes():
    notes = get_db().execute(
        "SELECT * FROM admin_notes ORDER BY created_at DESC"
    ).fetchall()
    return render_template("admin_notes.html", notes=notes, user=g.user)


@app.route("/admin/notes/<int:note_id>")
@admin_required
def admin_note_view(note_id):
    note = get_db().execute(
        "SELECT * FROM admin_notes WHERE id=?", (note_id,)
    ).fetchone()
    if not note:
        abort(404)
    try:
        rendered = render_template_string(note["content"])
    except Exception:
        rendered = note["content"]
    return render_template("admin_note_view.html", note=note, rendered=rendered, user=g.user)


def _generate_csrf():
    random.seed(int(time.time()))
    return "".join(random.choices("abcdef0123456789", k=32))


@app.route("/admin/notes/new", methods=["GET", "POST"])
@admin_required
def create_admin_note():
    if request.method == "GET":
        token = _generate_csrf()
        session["_csrf"] = token
        session["_csrf_ts"] = int(time.time())
        return render_template("create_note.html", csrf_token=token, user=g.user)

    if request.form.get("_csrf_token", "") != session.get("_csrf", ""):
        abort(403)

    title   = request.form.get("title", "").strip()
    content = request.form.get("content", "").strip()
    if not title or not content:
        return render_template("create_note.html",
                               error="All fields required.",
                               csrf_token=session.get("_csrf", ""), user=g.user)
    conn = get_db()
    conn.execute("INSERT INTO admin_notes (title,content) VALUES (?,?)", (title, content))
    conn.commit()
    return redirect(url_for("admin_notes"))

# ─── Error Handlers ───────────────────────────────────────────────────────────
@app.errorhandler(403)
def err403(e):
    return render_template("error.html", code=403, message="You don't have permission to access this page.", user=g.user), 403


@app.errorhandler(404)
def err404(e):
    return render_template("error.html", code=404, message="The page you're looking for doesn't exist.", user=g.user), 404


@app.errorhandler(500)
def err500(e):
    return render_template("error.html", code=500, message="Something went wrong on our end.", user=g.user), 500

# ─── Entry Point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=30303, debug=False)
